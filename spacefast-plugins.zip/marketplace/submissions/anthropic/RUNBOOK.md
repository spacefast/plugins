# Anthropic plugin directory submission

Status: **Blocked by hard-gate prerequisites**  
Customer-facing availability: **Not listed**  
Verified: **2026-08-27**

## Hard-gate blockers

- `published_setup_ui`
- `downstream_setup_ui_pins`
- `openai_app_registration`
- `live_openai_challenge`
- `reviewer_account`
- `submission_day_reverification`

## Submit

- Door: https://claude.ai/directory/manage/new/plugin
- Mechanism: portal
- Source: https://code.claude.com/docs/en/discover-plugins
- Source commit: `e318b07ef4efcb2f378a2424dab318cbcaecc204`
- Public plugin commit: `{{PLUGINS_SHA}}`
- Slug: `spacefast` (final; do not rename)
- Privacy: https://automattic.com/privacy/
- Terms: https://automattic.com/tos/
- Support: mailto:support@spacefast.com
- Reviewer account pointer: GitHub marketplace-reviewers environment: SPACEFAST_REVIEWER_ACCOUNT

## Upload or paste

- `marketplace/submissions/anthropic/entry.json`
- `plugins/assets/logo.png`
- `plugins/assets/logo-400.png`
- `plugins/assets/logo.svg`

## Final upstream check

Use the generated entry's tools, App-only callback names, server instructions, and prompt examples for the hosted Claude declaration. These fields use the Claude client profile. They describe this source version, not the currently deployed endpoint. Re-check the deployed connection before submitting them.

The tools array describes this source version's hosted MCP catalog at the declared endpoint. Each API operation is a named tool with its declared input and output schemas; resume_execution continues a saved call after its approval decision. publish, the Space App launchers, and show_domains open MCP Apps for the publish result, previews, deployments, source files and history, comments, analytics, build logs, databases, and domains. Verify the deployed authenticated catalog before submission; source metadata does not establish directory approval.

Verify the directory's third-party API custody requirements before submission.

The store copy, commands, URLs, keywords, and asset paths in these files are generated. Do not edit them by hand. The plugin sends no hook telemetry. CLI setup telemetry is disclosed before use and can be disabled with `SPACEFAST_TELEMETRY_DISABLED=1 or DO_NOT_TRACK=1`.
