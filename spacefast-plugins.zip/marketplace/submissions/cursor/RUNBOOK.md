# Cursor Marketplace submission

Status: **Live**  
Customer-facing availability: **Available**  
Verified: **2026-10-28**

## Hard-gate blockers

- None. The generated bundle passed every prerequisite.

## Submit

- Door: https://cursor.com/marketplace/publish
- Mechanism: portal
- Source: https://cursor.com/docs/reference/plugins
- Source commit: `e318b07ef4efcb2f378a2424dab318cbcaecc204`
- Public plugin commit: `{{PLUGINS_SHA}}`
- Slug: `spacefast` (final; do not rename)
- Privacy: https://automattic.com/privacy/
- Terms: https://automattic.com/tos/
- Support: https://automattic.com/contact/
- Reviewer account pointer: GitHub marketplace-reviewers environment: SPACEFAST_REVIEWER_ACCOUNT

## Upload or paste

- `marketplace/submissions/cursor/entry.json`
- `plugins/assets/logo.png`
- `plugins/assets/logo-400.png`
- `plugins/assets/logo.svg`

## Final upstream check

Use the generated entry as the pre-drafted portal, issue, API, or repository submission payload. Do not rewrite store copy by hand.

The store copy, commands, URLs, keywords, and asset paths in these files are generated. Do not edit them by hand. The plugin sends no hook telemetry. CLI setup telemetry is disclosed before use and can be disabled with `SPACEFAST_TELEMETRY_DISABLED=1 or DO_NOT_TRACK=1`.
