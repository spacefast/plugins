# Grok Build plugin marketplace submission

Status: **Blocked by hard-gate prerequisites**  
Customer-facing availability: **Not listed**  
Verified: **2026-08-27**

## Hard-gate blockers

- `published_setup_ui`
- `downstream_setup_ui_pins`
- `openai_app_registration`
- `live_openai_challenge`
- `reviewer_account`
- `submission_day_reverification`

## Submit

- Door: https://github.com/xai-org/plugin-marketplace/compare
- Mechanism: pull_request
- Source: https://github.com/xai-org/plugin-marketplace
- Source commit: `6e6aaa55e82c26ae5ae77654cb268c4eace06ceb`
- Public plugin commit: `{{PLUGINS_SHA}}`
- Slug: `spacefast` (final; do not rename)
- Privacy: https://automattic.com/privacy/
- Terms: https://automattic.com/tos/
- Support: https://automattic.com/contact/
- Reviewer account pointer: GitHub marketplace-reviewers environment: SPACEFAST_REVIEWER_ACCOUNT

## Upload or paste

- `marketplace/submissions/grok/entry.json`
- `marketplace/submissions/grok/.grok-plugin/spacefast-entry.json`
- `plugins/assets/logo.png`
- `plugins/assets/logo-400.png`
- `plugins/assets/logo.svg`

## Final upstream check

Append the generated object to `.grok-plugin/marketplace.json`, then run `python3 scripts/generate-plugin-index.py`, `python3 scripts/validate-catalog.py`, and `python3 scripts/generate-plugin-index.py --check`.

The store copy, commands, URLs, keywords, and asset paths in these files are generated. Do not edit them by hand. The plugin sends no hook telemetry. CLI setup telemetry is disclosed before use and can be disabled with `SPACEFAST_TELEMETRY_DISABLED=1 or DO_NOT_TRACK=1`.
