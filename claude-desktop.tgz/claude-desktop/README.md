# Spacefast for Claude Desktop

Publish local files and manage Spacefast spaces from Claude Desktop.

## Install

Download [`spacefast.mcpb`](https://github.com/spacefast/plugins/releases/latest/download/spacefast.mcpb)
and open it. If Claude Desktop does not open the bundle, go to **Settings → Extensions → Advanced
settings → Install Extension** and select the file.

## Use

Ask Claude: **Publish this folder with Spacefast.**

The extension runs the lean Spacefast On-Device MCP surface. It can publish local files
and run OpenAPI-generated operations in Spacefast's resumable code mode.

## Publish to your team

The API token requested during installation is optional. Leave it blank to publish anonymously and
receive a one-time claim link.

## Guides

- [Spacefast agent guide](https://spacefast.com/docs/agents)
- [Claude Desktop extension installation](https://support.claude.com/en/articles/10949351-getting-started-with-local-mcp-servers-on-claude-desktop)
- [Latest Spacefast release](https://github.com/spacefast/plugins/releases/latest)
