# Spacefast for Cursor

Publish local files and manage Spacefast spaces from Cursor. The plugin adds a project rule plus hosted
and local MCP connections.

## Install

Install the latest released plugin in Cursor's local plugin directory:

```bash
mkdir -p ~/.cursor/plugins/local/spacefast
curl -fsSL https://github.com/spacefast/plugins/releases/latest/download/cursor.tgz \
  | tar -xz --strip-components=1 -C ~/.cursor/plugins/local/spacefast
```

Restart Cursor or run **Developer: Reload Window**.

## Use

Ask Cursor: **Publish this project with Spacefast.** The rule applies automatically to
publish, deploy, host, and share requests.

Anonymous publishes need no account. Cursor returns the live URL and the one-time claim link.

## Included

- Publish files and folders, then update the same space
- Inspect versions and logs, diagnose failures, and roll back
- Handle anonymous claim links and account tokens safely
- Choose direct publish, hosted MCP, or On-Device MCP for the job
- Hosted MCP at `https://mcp.spacefast.com` for account and space operations
- On-Device MCP via `npx -y spacefast mcp` for local files and Spacefast code mode

## Publish to your team

Run `npx -y spacefast login` once before asking Cursor to publish.

## Guides

- [Spacefast agent guide](https://spacefast.com/docs/agents)
- [Cursor local plugin installation](https://cursor.com/docs/plugins#test-plugins-locally)
- [Spacefast CLI reference](https://spacefast.com/docs/cli)
