# Spacefast for Claude Code

Publish local files and manage Spacefast spaces without leaving Claude Code. The plugin adds a
`/spacefast` skill plus hosted and local MCP connections.

## Install

```bash
claude plugin marketplace add spacefast/plugins
claude plugin install spacefast@spacefast
```

Run `/reload-plugins` or start a new Claude Code session after installation.

## Use

Ask Claude: **Publish this project with Spacefast.** The skill runs automatically for
publish, deploy, host, and share requests.

Anonymous publishes need no account. Claude returns the live URL and the one-time claim link.

## Included

- Publish files and folders, then update the same space
- Inspect versions and logs, diagnose failures, and roll back
- Handle anonymous claim links and account tokens safely
- Choose direct publish, hosted MCP, or On-Device MCP for the job
- Hosted MCP at `https://mcp.spacefast.com` for account and space operations
- On-Device MCP via `npx -y spacefast mcp` for local files and Spacefast code mode

## Publish to your team

Sign in once before asking Claude to publish:

```bash
npx -y spacefast login
```

## Guides

- [Spacefast agent guide](https://spacefast.com/docs/agents)
- [Claude Code plugin installation](https://code.claude.com/docs/en/discover-plugins)
- [Spacefast CLI reference](https://spacefast.com/docs/cli)
