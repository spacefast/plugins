# Spacefast for Codex

Publish local files and manage Spacefast spaces from Codex. The plugin adds a `$spacefast`
skill plus hosted and local MCP connections.

## Install

```bash
codex plugin marketplace add spacefast/plugins
codex plugin add spacefast@spacefast
```

Start a new Codex task after installation.

## Use

Ask Codex: **Publish this project with Spacefast.** The skill can run automatically for
publish, deploy, host, and share requests.

Anonymous publishes need no account. Codex returns the live URL and the one-time claim link.

## Included

- Publish files and folders, then update the same space
- Inspect versions and logs, diagnose failures, and roll back
- Handle anonymous claim links and account tokens safely
- Choose direct publish, hosted MCP, or On-Device MCP for the job
- Hosted MCP at `https://mcp.spacefast.com` for account and space operations
- On-Device MCP via `npx -y spacefast mcp` for local files and Spacefast code mode

## Publish to your team

Run `npx -y spacefast login` once before asking Codex to publish.

## Skill only

If you do not want the plugin or MCP connections, install only the skill:

```bash
npx -y skills add spacefast/plugins --skill spacefast -g -a codex -y
```

## Guides

- [Spacefast agent guide](https://spacefast.com/docs/agents)
- [Codex plugin marketplaces](https://learn.chatgpt.com/docs/build-plugins#add-a-marketplace-from-the-cli)
- [Spacefast CLI reference](https://spacefast.com/docs/cli)
